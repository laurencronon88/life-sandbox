# THE BED EDIT — Photography Review v2 (NOT FINAL)

This folder contains **18 individual seasonal WebP candidates**, a side-by-side contact sheet, and manifest. The original bedroom photographs were used as visual reference. Two Crisp & Classic hero frames were replaced with a tighter summer/winter pair using a diamond-stitched quilt; Airy & Luminous hero remains the prior lighter revision.

**These are not approved production files.** Remaining camera-angle, quilt texture, decorative object, and concept-differentiation QA blockers remain. AI imagery is illustrative, and cannot be described as verified imagery of retail products. A few winter images still have incorrect channel stitching, so do not deploy this as a complete final set.

Paths follow `{concept}-{season}-{angle}.webp`, and all 18 files are physically present.

**Important:** Lauren's weighted blanket is personal, not a shared overbed blanket. Exact Matouk Milano double-stitched diamond pattern requires accurate representation in *every* winter frame before approval.

## Upload status
These assets are available as local conversation output, but are **not yet committed to GitHub and not attached to the ChatGPT Project file panel**. GitHub branch `bed-edit/photography-review` contains only handoff documentation.
